%c={'jb980607';'jb980609';'jb980622';'jb980628';'jb970826_24';'jb970826_288';'jb980626_288';'lgg'};
%skriv c som string value i listboxen
%c={'jarnbrott_970826_3600s';'jarnbrott_970826_300s';'jarnbrott_980607_300s';'jarnbrott_980608_300s';'jarnbrott_980609_300s';'jarnbrott_980610_300s';'jarnbrott_980622_300s';'jarnbrott_980626_300s';'jarnbrott_980628_300s';'jarnbrott_980629_300s';'jarnbrott_980607_12_300s'};
c={'rain1_1d_3600s';'rain1_1d_300s';'rain2_1d_300s';'rain3_1d_300s';'rain4_1d_300s';'rain5_1d_300s';'rain6_1d_300s';'rain7_1d_300s';'rain8_1d_300s';'rain9_1d_300s';'rain10_6d_300s'};
