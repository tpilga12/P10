%File runoff.m 
%This file sets the reservoir parameter
%This file is loaded from prep.m
%Stefan Ahlman
%2000-02-23

K=in_K;
